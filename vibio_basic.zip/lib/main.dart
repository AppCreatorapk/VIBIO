import 'package:flutter/material.dart';

void main() {
  runApp(const VibioApp());
}

class VibioApp extends StatelessWidget {
  const VibioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Vibio")),
      body: const Center(
        child: Text("Welcome to Vibio! Basic Version"),
      ),
    );
  }
}
